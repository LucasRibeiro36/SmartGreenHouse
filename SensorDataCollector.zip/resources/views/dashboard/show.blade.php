
    <div class="container">
        <h1>Dashboard</h1>
        <h1>Led: </h1>
        <button id="led-on" class="btn btn-primary">ON</button>
        <button id="led-off" class="btn btn-danger">OFF</button>
        <h1>Bomba:</h1>
        <button id="bomba-on" class="btn btn-primary">ON</button>
        <button id="bomba-off" class="btn btn-danger">OFF</button>
        <h1>Temperature Sensor Data</h1>
       
       <a href="/SensorDataCollector/public/show_temp_data" class="btn btn-primary">Temperature Data</a>
       <a href="/SensorDataCollector/public/show_temp_graph_data" class="btn btn-primary">Temperature Graph Data</a>
       <a href="/SensorDataCollector/public/show_temp_data" class="btn btn-primary">Soil Data</a>

    </div>
