<?php

namespace App\Http\Controllers\Api\V1;

class SmartLedController extends Controller{

}
